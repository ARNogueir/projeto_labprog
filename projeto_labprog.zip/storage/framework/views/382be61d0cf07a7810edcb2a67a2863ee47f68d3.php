 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet"
              id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://bootswatch.com/4/simplex/bootstrap.min.css"/>

        <div class="container">
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>" class="nav-link">Informação Básica</a>
                <a class="nav-link" href="<?php echo e(url('/conference')); ?> " class="nav-link">Minhas Conferências</a>
                <a class="nav-link" href="<?php echo e(url('/admin_conferences')); ?> " class="nav-link">Todas as Conferências</a>
            </div>
            <div class="tab-content ml-1" id="myTabContent">
                <div class="row">
                    <div class="col-sm-3 col-md-2 col-5">
                        <label style="font-weight:bold;"><br>Nome</label>
                    </div>
                    <div class="col-md-8 col-6"><br>
                        <?php echo e(Illuminate\Support\Facades\Auth::user()->name); ?>

                    </div>
                </div>
                <hr/>
                <div class="row">
                    <div class="col-sm-3 col-md-2 col-5">
                        <label style="font-weight:bold;">E-mail</label>
                    </div>
                    <div class="col-md-8 col-6">
                        <?php echo e(Illuminate\Support\Facades\Auth::user()->email); ?>

                    </div>
                </div>
                <hr/>
            </div>
        </div>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\projeto_labprog\projeto_labprog\resources\views/dashboard.blade.php ENDPATH**/ ?>