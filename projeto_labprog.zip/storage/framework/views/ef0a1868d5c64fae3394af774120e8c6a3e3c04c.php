 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet"
              id="bootstrap-css">
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://bootswatch.com/4/simplex/bootstrap.min.css"/>

        <div class="container">
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>" class="nav-link">Informação Básica</a>
                <a class="nav-link" href="<?php echo e(url('/users_conferences')); ?> " class="nav-link">Conferências</a>
            </div>

            <div class="tab-content ml-1" id="myTabContent">
                <?php $__currentLoopData = $conferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;">ID</label>
                        </div>
                        <div class="col-md-8 col-6">
                            <td width=300 height=100><?php echo e($conference->id); ?></td>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;"><br>Nome</label>
                        </div>
                        <div class="col-md-8 col-6"><br>
                            <td><?php echo e($conference->name); ?></td>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;">Descrição</label>
                        </div>
                        <div class="col-md-8 col-6">
                            <td width=300 height=100><?php echo e($conference->descricao); ?></td>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;">Local</label>
                        </div>
                        <div class="col-md-8 col-6">
                            <td width=300 height=100><?php echo e($conference->local); ?></td>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;">Lotação</label>
                        </div>
                        <div class="col-md-8 col-6">
                            <td width=300 height=100><?php echo e($conference->lotacao); ?></td>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;">Inscritos</label>
                        </div>
                        <div class="col-md-8 col-6">
                            <td width=300 height=100><?php echo e($conference->inscritos); ?></td>
                        </div>
                    </div>
                    <hr/>
                    <div class="row">
                        <div class="col-sm-3 col-md-2 col-5">
                            <label style="font-weight:bold;">Data</label>
                        </div>
                        <div class="col-md-8 col-6">
                            <td width=300 height=100><?php echo e($conference->data); ?></td>
                        </div>
                    </div>
                    <hr/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($conferences->links()); ?>

        </div>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\projeto_labprog\projeto_labprog\resources\views/users/users_conferences.blade.php ENDPATH**/ ?>