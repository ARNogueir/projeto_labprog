<?php echo $__env->make('components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
<header>
    <?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <br>
    <br>
    <h2><br>Criar Nova Conferência</h2><br>
</header>

<form action="<?php echo e(route('image.upload.post')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="name">Nome:</label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name')); ?>"
               placeholder="Insira o Nome">
    </div>
    <div class="form-group">
        <label for="localizacao">Local:</label>
        <input type="text" name="localizacao" id="localizacao" class="form-control" value="<?php echo e(old('local')); ?>"
               placeholder="Insira o Local">
    </div>
    <div class="form-group">
        <label for="lotacao">Lotação:</label>
        <input type="number" name="lota" id="lota" class="form-control" value="<?php echo e(old('lotacao')); ?>"
               placeholder="Insira a Lotação">
    </div>

    <div class="form-group">
        <label for="descricao">Descrição:</label>
        <input type="text" name="descricao" id="descricao" textarea class="form-control" value="<?php echo e(old('descricao')); ?>"
               placeholder="Insira a Descrição">
    </div>

    <div class="form-group">
        <label for="data">Escolher data:</label>
        <input type="datetime-local" name="data" id="data" class="form-control" value="date">
    </div>
    <div class="form-group">
        <label for="exampleFormControlFile1">Imagem de Apresentação</label>
        <input type="file" name="image" class="form-control"></div>
    <button type="submit" class="btn btn-outline-success">Criar</button>

</form>
<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\Projetos\Labprog\projeto_labprog\resources\views/conf/conf_create.blade.php ENDPATH**/ ?>