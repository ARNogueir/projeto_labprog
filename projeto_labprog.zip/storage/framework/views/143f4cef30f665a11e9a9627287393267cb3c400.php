<?php echo $__env->make('components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<header>
    <?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<br>
<br>
<br>
<?php if((Illuminate\Support\Facades\Auth::user()->admin) ==1): ?>
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <a class="nav-link" href="<?php echo e(url('/admin')); ?>" class="nav-link">
                <button type="button" class="btn btn-outline-secondary">Utilizadores</button>
            </a>
            <a class="nav-link" href="<?php echo e(url('/admin_conferences')); ?>" class="nav-link">
                <button type="button" class="btn btn-outline-secondary">Conferências</button>
            </a>
            <a class="nav-link" href="<?php echo e(url('/conf_create')); ?>" class="nav-link">
                <button type="button" class="btn btn-outline-success">Nova Conferência</button>
            </a>
        </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <table class="table table-hover">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Local</th>
                    <th>lotação</th>
                    <th>Inscritos</th>
                    <th>Data</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $conferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($conference->id); ?></td>
                        <td><?php echo e($conference->name); ?></td>
                        <td width=300 height=100>><?php echo e($conference->descricao); ?></td>
                        <td><?php echo e($conference->local); ?></td>
                        <td><?php echo e($conference->lotacao); ?></td>
                        <td><?php echo e($conference->inscritos); ?></td>
                        <td><?php echo e($conference->data); ?></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Opções
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="inscricao/<?php echo e($conference->id); ?>">Inscrever-me</a>
                                    <a class="dropdown-item" href="#">Editar Conferência</a>
                                    <a class="dropdown-item" href="#">Ver Inscritos</a>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($conferences->links()); ?>

        </div>
    </div>
<?php else: ?>
    Nao tem autorização para ver esta pagina
<?php endif; ?>

<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\Projetos\Labprog\projeto_labprog\resources\views/admin_conferences.blade.php ENDPATH**/ ?>