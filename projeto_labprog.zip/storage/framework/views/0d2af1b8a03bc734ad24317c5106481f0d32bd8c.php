<?php echo $__env->make('components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

<header>
    <?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<br>
<br>
<br>
<?php if((Illuminate\Support\Facades\Auth::user()->admin) ==1): ?>
    <nav>
        <div class="nav nav-tabs" id="nav-tab" role="tablist">
            <a class="nav-link" href="<?php echo e(url('/admin')); ?>" class="nav-link">
                <button type="button" class="btn btn-outline-secondary">Utilizadores</button>
            </a>
            <a class="nav-link" href="<?php echo e(url('/admin_conferences')); ?>" class="nav-link"><button type="button" class="btn btn-outline-secondary">Conferências</button></a>
        </div>
    </nav>

    <div class="tab-content" id="nav-tabContent">
        <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
            <table class="table table-hover">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Perfil</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <?php if($user->admin=='1'): ?>
                            <td>Admin</td>
                        <?php else: ?>
                            <td>Utilizador</td>
                        <?php endif; ?>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Opções
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <a class="dropdown-item" href="profile/<?php echo e($user->id); ?>">Ver Perfil</a>
                                    <a class="dropdown-item" href="">Editar Perfil</a>
                                    <a class="dropdown-item" href="admin/<?php echo e($user->id); ?>">Eliminar Perfil</a>
                                    <?php if($user->admin=='1'): ?>
                                        <a class="dropdown-item" href="updateUser/<?php echo e($user->id); ?>">Tornar Utilizador Normal</a>
                                    <?php else: ?>
                                        <a class="dropdown-item" href="updateAdmin/<?php echo e($user->id); ?>">Tornar Administrador</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
    </div>
<?php else: ?>
    Sem permissões para ver esta página.
<?php endif; ?>
<?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</body>
</html>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>admin.blade.php
<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\Projetos\Labprog\projeto_labprog\resources\views/admin.blade.php ENDPATH**/ ?>