<?php echo $__env->make('components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<br>
<br>
<br>
teste
<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\projeto_labprog\projeto_labprog\resources\views/inscricao.blade.php ENDPATH**/ ?>