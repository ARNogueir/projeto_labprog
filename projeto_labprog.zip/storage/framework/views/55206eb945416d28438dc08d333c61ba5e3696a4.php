<?php echo $__env->make('components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<br>
<h3 class="text-center">nome:<?php echo e($user->name); ?> id:<?php echo e($user->id); ?>  email:<?php echo e($user->email); ?></h3>

<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\Projetos\Labprog\projeto_labprog\resources\views/profile.blade.php ENDPATH**/ ?>