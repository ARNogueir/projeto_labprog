<!DOCTYPE html>
<link href="<?php echo e(asset('css/index/index.css')); ?>" rel="stylesheet">
<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid">
        <img id="img_logo" src="<?php echo e(asset('img/navbar_logo.png')); ?>" alt="logo">
        <a class="navbar-brand">Conferências - Ciência & Sociedade</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
                aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav me-auto mb-2 mb-md-0">
                <li class="nav-item active">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>" class="nav-link">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/conf')); ?>" class="nav-link">Conferências</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/about')); ?>" class="nav-link">Sobre Nós</a>
                </li>
            </ul>
            <div
                class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">
                <?php if(Route::has('login')): ?>
                    <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(url('/dashboard')); ?>" class="#">
                                <button type="button" class="btn btn-light">Área Pessoal</button>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="#">
                                <button type="button" class="btn btn-light">Login</button>
                            </a>
                            <?php if(Route::has('register')): ?>
                                <a href="<?php echo e(route('register')); ?>"
                                   class="#">
                                    <button type="button" class="btn btn-light">Registar</button>
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\projeto_labprog\projeto_labprog\resources\views/components/nav.blade.php ENDPATH**/ ?>