<?php
@include('components.head');
@include('components.nav');

teste


 ?><?php /**PATH C:\Users\a_nog\OneDrive\Ambiente de Trabalho\projeto_labprog\projeto_labprog\resources\views/userConference.blade.php ENDPATH**/ ?>
