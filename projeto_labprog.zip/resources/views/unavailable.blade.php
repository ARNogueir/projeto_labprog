@include('components.head')

<body>
<header>
    @include('components.nav')
</header>
<h2 class="featurette-heading">Página Em Construção<p></p></h2>


@include('components.footer');
</body>

