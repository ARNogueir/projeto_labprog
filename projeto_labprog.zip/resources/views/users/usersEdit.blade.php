@include('components.head')
@include('components.nav')

<body>

@include('components.footer')
</body>
