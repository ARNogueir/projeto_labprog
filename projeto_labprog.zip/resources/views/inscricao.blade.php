@include('components.head')
@include('components.nav');

<br>
<br>
<br>
teste
