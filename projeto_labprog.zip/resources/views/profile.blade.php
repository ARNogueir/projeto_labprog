@include('components.head')
@include('components.nav')

<br>
<br>
<h3 class="text-center">nome:{{$user->name}} id:{{$user->id}}  email:{{$user->email}}</h3>

